#!/usr/bin/env python

import wsgiref.handlers
import os
import facebook
from google.appengine.ext import webapp
from google.appengine.ext.webapp import template
from google.appengine.ext import db

class BaseHandler(webapp.RequestHandler):
  def get(self):
    self.API_KEY = ''# YOUR API KEY
    self.SECRET_KEY = ''# YOUR SECRET KEY
    self.facebookapi = facebook.Facebook(self.API_KEY, self.SECRET_KEY)

    if not self.facebookapi.check_connect_session(self.request):
      self.tpl('login.html')
      return

    try:
      self.user = self.facebookapi.users.getInfo(
        [self.facebookapi.uid],
        ['uid', 'name', 'birthday', 'relationship_status'])[0]
    except facebook.FacebookError:
      self.tpl('login.html')
      return

    self.get_secure()

  def tpl(self, tpl_file, vars = {}):
      vars['apikey'] = self.API_KEY
      path = os.path.join(os.path.dirname(__file__), 'templates/' + tpl_file)
      self.response.out.write(template.render(path, vars))

class MainHandler(BaseHandler):
  def get_secure(self):
    template_values = {
      'name': self.user['name'],
      'birthday': self.user['birthday'],
      'relationship_status': self.user['relationship_status'],
      'uid': self.user['uid']
    }

    self.tpl('index.html', template_values)

def main():
  application = webapp.WSGIApplication([('/', MainHandler)], debug=True)
  wsgiref.handlers.CGIHandler().run(application)

if __name__ == '__main__':
  main()

